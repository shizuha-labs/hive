# Third-party notices

Generated from the actual bundled module graph. Original installed dependency
license and notice files are copied without modification under LICENSES/.
Dependencies externalized from these bundles remain separately distributed.


